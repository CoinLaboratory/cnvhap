package rAssociation;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.rosuda.JRI.REXP;
import org.rosuda.JRI.RList;
import org.rosuda.JRI.Rengine;

import cern.colt.matrix.linalg.Algebra;

public class Assoc {

	public static void main(String[] args){
		try{
			Constants.parse(args);
			File user = new File(System.getProperty("user.dir"));
			File pheno = new File(user, "pheno.txt");
			File limit = new File(user, "limit.txt");
			File exclude = new File(user, "exclude.txt");
			String suff = Constants.experiment+"_1_"+Constants.mid[0];
			for(int k=1; k<Constants.mid.length; k++){
				suff+="_"+Constants.process(Constants.mid[k]);
			}
			File avgDir = new File(user, suff+"/avg");
			File[] l = avgDir.listFiles(new FileFilter(){

				@Override
				public boolean accept(File pathname) {
				return pathname.getName().endsWith(".txt") && ! pathname.getName().startsWith("result_");
				}
				
			});
			File avg = l.length==1 ? l[0] : new File(avgDir,Constants.experiment+".txt");
			
			Assoc assoc = new Assoc(avg, pheno,limit, exclude, Constants.type);
			assoc.run();
			System.exit(0);
		}catch(Exception exc){
			exc.printStackTrace();
		}
	}
	Rengine re=new Rengine(new String[] {"--vanilla"}, false, null);	
	final PrintWriter[] pw;
	final double[][] phenotypes; //by phenotype, and then indiv
	final double[][] covariates; //by covariate, then indiv
	final double[][] genotypes; //by snp, then indiv
	String[] pheno_name;
	
	final List<String> indiv ;
	final int[] snp_col_ind;
	BufferedReader cnvs;
	int[] pheno_alias; //maps pheno row to correct row in pheno matrix
	

	
	private void  getSubset(List<String> split, String suff, List<String> res,List<String> res_all,  List<String>exclude) {
		List<Integer> inds = new ArrayList<Integer>();
		for(int k=0; k<split.size(); k++){
			int ind = split.get(k).lastIndexOf(suff);
			if(ind>=0){
				String indv =split.get(k).substring(0,ind);
				if(!exclude.contains(indv)){
					res.add(indv);
					res_all.add(indv);
				//	inds.add(k);
				}
				else{
					res_all.add(split.get(k));
				}
			}
			else{
				res_all.add(split.get(k));
			}
		}
		
		//return inds;
	}

	
	final List<String> covar, pheno;
	
	
	
	boolean transpose = false;
	//This is constructor
	
	List<String> probeids;
	List<String> loc = new ArrayList<String>();
	String chrom;
	
	Algebra alg = new Algebra();
	String header = "rsid    chrom   loc     pheno   N_case  N_control       beta    se      pvalue";
	
	//first index of geno, second of pheno
	
	String assocline = "y ~ x";
	
	public void run(int i, int k){
		
		double[] geno = this.genotypes[i];
		double[] pheno = this.phenotypes[k];
		re.assign("y", pheno);
		re.assign("x", geno);
		for(int k1=0; k1<covariates.length; k1++){
			re.assign("cov_"+k1, covariates[k1]);
		}
		re.eval("summ= summary(lm("+assocline+"))");
        REXP summ = re.eval("summ");
        RList names= re.eval("dimnames(summ$coefficients)").asList();
        double[][]coeff = summ.asList().at("coefficients").asMatrix();
        int indrow = Arrays.asList(names.at(0).asStringArray()).indexOf("x");
 //       String[] names1 = names.at(1).asStringArray();
        if(indrow>=0 && indrow<coeff.length){
        	double beta   = coeff[indrow][0];
       
      double se = coeff[indrow][1];
      double pv =  coeff[indrow][3];
      this.pw[k].print(this.probeids.get(i)+"\t");
      this.pw[k].print(this.chrom+"\t");
      this.pw[k].print(this.loc.get(i)+"\t");
      this.pw[k].print(this.pheno.get(k)+"\t");
      this.pw[k].print("NA\t");
      this.pw[k].print("NA\t");
      this.pw[k].print(String.format("%5.3g", beta)+"\t");
      this.pw[k].print(String.format("%5.3g", se)+"\t");
      this.pw[k].print(String.format("%5.3g", pv)+"\n");
        }
	}
	public void run(){
		for(int i=0; i<genotypes.length; i++){
			for(int k=0; k<phenotypes.length; k++){
				run(i,k);
			}
		}
		for(int k=0; k<phenotypes.length; k++){
			pw[k].close();
		}
	}
	
	public Assoc(File avgFile, File phenoFile, File limitFile, File excludeFile, String suff) throws Exception{
		 covar = new ArrayList<String>();
		 pheno = new ArrayList<String>();
		 chrom = Constants.mid[0];
		 
		cnvs = new BufferedReader(new FileReader(avgFile));
		List<String> avg_file_indiv = new ArrayList<String>();
		List<String> avg_file_indiv_all = new ArrayList<String>();
		List<String> cnvline = Arrays.asList(cnvs.readLine().split("\t"));
		transpose = !cnvline.get(1).equals("loc");
		 
		String st = "";
		List<String> genoline = new ArrayList<String>();
		genoline.add("snpid");
		for(int i=0; (st = cnvs.readLine())!=null; i++){
			String[] str_ = st.split("\t");
			genoline.add(str_[0]);
			if(transpose){
				if(i==0){
					loc.addAll(Arrays.asList(str_));
				}
			}
			else{
				loc.add(str_[1]);
			}
		}
		cnvs.close();
		
		if(transpose){
			List<String> tmp = genoline;
			genoline = cnvline;
			cnvline = tmp;
		}
		cnvline.remove(0);
		probeids = genoline.subList(1, genoline.size());
		int[] geno_col_ind = getPhenoInd(probeids,genoline);
		
		
		getSubset(cnvline, "_"+suff, avg_file_indiv,avg_file_indiv_all, read(excludeFile));
		BufferedReader br1 = new BufferedReader(new FileReader(phenoFile));
		List<String >phen_head = Arrays.asList(br1.readLine().split("\t")); //header
		read(limitFile, covar, "covar", phen_head);
		read(limitFile, pheno, "pheno", phen_head);
		if(pheno.size()==0){
			pheno.addAll(phen_head.subList(1, phen_head.size()));
		}
		int[] covar_ind = getPhenoInd(covar,phen_head);
		int[] pheno_ind = getPhenoInd(pheno, phen_head);
	
		List<String> pheno_indiv = new ArrayList<String>();
		for(;(st =br1.readLine())!=null;){
			String[]  str = st.split("\t");
			pheno_indiv.add(str[0]);
		}
		br1.close();
		indiv = new ArrayList<String>(pheno_indiv);
		indiv.retainAll(avg_file_indiv);
		int[] pheno_indiv_ind = getPhenoInd(indiv, pheno_indiv);
		this.snp_col_ind = getPhenoInd(indiv, avg_file_indiv_all);
		this.covariates = readMatrix(covar_ind, pheno_indiv_ind, phenoFile, covar.size());
		this.phenotypes = readMatrix(pheno_ind, pheno_indiv_ind, phenoFile, pheno.size());
		this.genotypes =
			transpose ? 
			readMatrix(geno_col_ind, snp_col_ind, avgFile, this.probeids.size()):
				transpose(readMatrix(snp_col_ind, geno_col_ind, avgFile, this.indiv.size()));
		pw = new PrintWriter[this.pheno.size()];
		for(int k=0; k<pw.length; k++){
			pw[k] = new PrintWriter(new BufferedWriter(new FileWriter(new File(avgFile.getParentFile(),"result_"+pheno.get(k)+".txt"))));
			pw[k].println(header);	
			pw[k].flush();
		}
		for(int k=0; k<covariates.length; k++){
			assocline+="+cov_"+k;
		}
		
	}

	
	
	private double[][] transpose(double[][] m) {
		double[][] res = new double[m[0].length][m.length];
		for(int k=0; k<m.length; k++){
			for(int j=0; j<res.length; j++){
				res[j][k] = m[k][j];
			}
		}
		return res;
	}

	private double[][] readMatrix(int[] col_ind, int[] row_ind, File phenoFile, int numcols) throws Exception{
		double[][]phenotypes = new double[numcols][indiv.size()];
//		DoubleMatrix2D phenotypes = new DenseDoubleMatrix2D(indiv.size(), numcols);
		if(numcols==0) return phenotypes;
		 BufferedReader br1 = new BufferedReader(new FileReader(phenoFile));
		 br1.readLine();
		 String st;
		 for(int i=0 ;(st = br1.readLine())!=null;i++){
			 String[] str = st.split("\t");
			 if(row_ind[i]>=0){
				 String pred = str[0].split("_")[0];
				 String act = indiv.get(row_ind[i]);
				 
				 if(!act.equals(pred)) {
					 throw new RuntimeException("!!");
				 }
				 for(int k=0; k<str.length; k++){
					 if(col_ind[k]>=0){
						 String v = str[k];
						 if(v.equals("NA")) v = "NaN";
						 phenotypes[ col_ind[k]][ row_ind[i]] =  Double.parseDouble(v);
					 }
				 }
				
			 }
		 }
		 br1.close();
		 return phenotypes;
	}

	private int[] getPhenoInd(List<String> subsample, List<String> list) {
		int[] res = new int[list.size()];
		for(int k=0; k<res.length; k++){
			res[k] = subsample.indexOf(list.get(k));
		}
		return res;
	}

	private List<String> read(File excludeFile) throws Exception {
		List<String> res = new ArrayList<String>();
		if(excludeFile.exists()){
			BufferedReader br = new BufferedReader(new FileReader(excludeFile));
			String st = "";
			while((st = br.readLine())!=null){
				res.add(st);
			}
			br.close();
		}
		
		return res;
	}
	
	private void read(File excludeFile, List<String> res, String match, List<String> phens) throws Exception {
		
		if(excludeFile.exists()){
			BufferedReader br = new BufferedReader(new FileReader(excludeFile));
			String st = "";
			while((st = br.readLine())!=null){
				String[] str = st.split("\t");
				if(str[1].equals(match) 
						&& ( phens.contains(str[0]))){
					res.add(str[0]);
				}
			}
			br.close();
		}
		
	}
	
}
