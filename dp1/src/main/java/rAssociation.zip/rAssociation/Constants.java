package rAssociation;

import java.awt.Color;
import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Arrays;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.Parser;
import org.apache.commons.cli.PosixParser;

public class Constants {
	
	public static final Options OPTIONS = new Options(){
		{
			Field[] f = Constants.class.getFields();
			for(int i=0; i<f.length; i++){
				if(Modifier.isStatic(f[i].getModifiers())){
					
					this.addOption(OptionBuilder.withLongOpt(f[i].getName()).withValueSeparator(':').hasArgs().create());
				}
			}
		}
	};

	public static String experiment = "";
	public static String type = "countAll";
	public static String[] mid = new String[0];
	
	   public static CommandLine parse(String[] args) throws Exception{
		Parser parser = new PosixParser();
		CommandLine cli  = parser.parse(OPTIONS, args);
		
		
		if(cli.hasOption("experiment")) experiment = cli.getOptionValue("experiment");
		if(cli.hasOption("mid")) mid = cli.getOptionValues("mid");
		if(cli.hasOption("type")) type = cli.getOptionValue("type");
		return cli;
	}
	   
	   public static int process(String txt){
	  		
	  		int ind = txt.indexOf("mb");
	  		if(ind>=0){
	  			return (int) Math.round(1000000*Double.parseDouble(txt.substring(0,ind)));
	  		}
	  		 ind = txt.indexOf("kb");
	  		if(ind>=0){
	  			return (int) Math.round(1000*Double.parseDouble(txt.substring(0,ind)));
	  		}
	  		 ind = txt.indexOf("gb");
	  		if(ind>=0){
	  			return (int) Math.round(1000000000*Double.parseDouble(txt.substring(0,ind)));
	  		}
	  		
	  		else return (int) Math.round(Double.parseDouble(txt));
	  	}
	
}
